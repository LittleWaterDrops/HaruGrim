<template>
    <div>
        <h1>Main View</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>