package com.yh.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	// 비밀번호 인코더 (BCrypt 사용)
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	// 사용자 정의 UserDetailsService (예시로 InMemoryUserDetailsManager 사용)
	@Bean
	public UserDetailsService userDetailsService() {
	    User.UserBuilder userBuilder = User.withUsername("user")
	            .password(passwordEncoder().encode("password"))
	            .roles("USER");  // 사용자가 "USER" 권한을 가짐
	    return new InMemoryUserDetailsManager(userBuilder.build());
	}


	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests() // 권한 설정
				.requestMatchers("/swagger-ui/**", "/swagger-resources/**", "/webjars/**", "/swagger-ui.html",
						"/swagger-ui/index.html", "/v3/api-docs/**", "/users/auth/signup", "/users/auth/login")
				.permitAll() // 인증 없이 접근 가능한 경로
				.requestMatchers(HttpMethod.GET, "/users/my").authenticated() // 프로필 조회는 인증 필요
				.anyRequest().authenticated() // 나머지 API는 인증 필요
				.and().formLogin() // 폼 로그인 사용 (HTTP Basic 대신)
				.loginPage("/login").permitAll().and().logout() // 로그아웃 설정
				.permitAll().and().csrf().disable() // Swagger 사용을 위해 CSRF 보호를 비활성화
				.sessionManagement().sessionFixation().newSession() // 세션 고정 공격 방지
				.invalidSessionUrl("/login"); // 세션 만료 후 리다이렉트할 URL 설정
	}
}
