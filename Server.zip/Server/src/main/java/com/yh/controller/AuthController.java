package com.yh.controller;

public class AuthController {

}
